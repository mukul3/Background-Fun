var r = 0;
var g = 250;
var b=255;

var circle1 ;

// INITIALIZE ALL YOUR VARIABLES
// Ideally you would create 3 variables. red blue green or r, g, b

function setup(){

  createCanvas(700,500);
}


function draw(){
  
  background("white");

  // change the value of Red based on the mouse movement about the X axis
    r = mouseX;
  // change the value of Green based on the mouse movement about the X axis
    g = mouseX;
  // change the value of Blue based on the mouse movement about the X axis
    b = mouseX;

  // Use the map() function to do so. 
  r = map(mouseX,0,700,0,255);
  g = map(mouseX,0,700,0,255);
  b = map(mouseX,0,700,0,255);

  // Pass the values to the background() function you have learnt previously.
  background(0,g,b);

  // Create an ellipse that will move around with you mouse about the X axis.
  ellipse(mouseX,mouseY,50,50);
  
  // Remember to fill the canvas with white paint before creating the ellipse.
}